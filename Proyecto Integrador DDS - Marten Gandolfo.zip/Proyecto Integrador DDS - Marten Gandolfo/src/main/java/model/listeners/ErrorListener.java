package model.listeners;

public interface ErrorListener {
    void didErrorOccurred(String errorMessage);
}

package model.listeners;

public interface SearchListener {

    void didFindArticleCoincidences();

    void didFindArticleContent();
}

package model.listeners;

public interface LoadArticleListener {
    void didLoadTitles();
    void didLoadArticleContent();
}
